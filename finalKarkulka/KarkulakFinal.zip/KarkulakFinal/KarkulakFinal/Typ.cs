﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KarkulakFinal
{
    public enum Typ
    {
        DOMOV,
        BABICKA,
        VLK,
        LOUKA,
        VYHLIDKA,
        BLUDNY_KOREN,
        PREKAZKA
    }
}
